//
// Created by bensi on 01/07/2024.
//

#include <iostream>
#include <cstring>
#include "Team.h"
using namespace std;


Team :: Team()
{
    name = nullptr;
    goodpoints = 0;
    badpoints = 0;
    win = 0;
    draw = 0;
    loose = 0;
}

void Team :: set_name (char *str)
{
     name = new char (strlen(str) +1);
        strcpy( name, str);
}

char* Team :: get_name() const
{
    return name;
}

void Team :: game (int good, int bad)
{
    goodpoints = good;
    badpoints = bad;
    if(goodpoints > badpoints)
        win = win + 1;
    if (goodpoints < badpoints)
        loose = loose + 1;
    if (goodpoints == badpoints)
        draw = draw + 1;
}

int Team ::points ()const
{
    int points = 0;
    points = draw + (3 * win);
    return points;
}

void Team::print()const
{
    cout << name <<" have: "<<win <<" wins | "<<draw<<" draws | "<<loose<<" looses | "<<"points: "<< points()<<endl;
}

Team::~Team()
{
    delete[] name;
}



