//
// Created by bensi on 01/07/2024.
//

#ifndef WORK1_LEAGUE_TEAM_H
#define WORK1_LEAGUE_TEAM_H


class Team {
private:
    char* name;
    int goodpoints;
    int badpoints;
    int win;
    int draw;
    int loose;
public:
    Team ();
    ~Team();
    void set_name (char *str);
    char* get_name ()const;
    void game (int good, int bad);
    int points ()const;
    void print ()const;
};


#endif //WORK1_LEAGUE_TEAM_H
