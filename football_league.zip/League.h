//
// Created by bensi on 01/07/2024.
//

#ifndef WORK1_LEAGUE_LEAGUE_H
#define WORK1_LEAGUE_LEAGUE_H

#include "Team.h"
class League{
private:
        int size;
        Team *teams;
public:
    League (int size, char** names);
    bool game (int points1, char* group1, int points2, char* group2);
    void print() const;
    ~League();
    };


#endif //WORK1_LEAGUE_LEAGUE_H
