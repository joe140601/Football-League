#include <iostream>
#include <cstring>
#include "League.h"
#define SIZE 20
using namespace std;

int main()
{
    int size, another=0;
    bool again = true;
    char **teams = nullptr;
    cout << "Enter number of teams in the league: ";
    cin >> size;
    cin.ignore();

    teams = new char*[size];
    cout << "Please enter the names of the teams in the league:" << endl;
    for (int i = 0; i < size; ++i)
    {
        char tmp[SIZE];
        cout << "Team " << (i + 1) << ": ";
        cin.getline(tmp, SIZE);
        teams[i] = new char[strlen(tmp) + 1];
        strcpy(teams[i], tmp);
    }

    League league(size, teams);

    while (again)
    {
        char team1[SIZE], team2[SIZE];
        int points1, points2;

        cout << "Enter the first team name for the game: ";
        cin >>team1;

        cout << "Enter the points scored by " << team1 << ": ";
        cin >> points1;

        cout << "Enter the second team name for the game: ";
        cin >> team2;

        cout << "Enter the points scored by " << team2 << ": ";
        cin >> points2;

        if (league.game(points1, team1, points2, team2))
            cout << "Game played successfully between " << team1 << " and " << team2 << endl;
        else {
            cout << "One or both teams are not in the league." << endl;
        }
        league.print();

        cout << "Another game? (Enter 1 for yes, 0 for no): ";
        cin >> another;

        if (another == 0)
        {
            again = false;
        }
    }
    for (int i = 0; i < size; ++i)
        delete[] teams[i];
    delete[] teams;

    return 0;
}
