//
// Created by bensi on 01/07/2024.
//
#include <iostream>
#include "League.h"
#include "Team.h"
#include <cstring>
using namespace std;

League::League(int size, char **names)
{
    this -> size = size;
     teams = new Team [size];
     for (int i=0; i<size;i++)
         teams[i].set_name(names[i]);

}
League::~League()
{
    delete[] teams;
}

bool League::game(int points1, char *group1, int points2, char *group2)
{
    Team *team1 = nullptr;
    Team *team2 = nullptr;

    for (int i = 0; i < size; ++i)
    {
        if (strcmp(teams[i].get_name(), group1) == 0)
        {
            team1 = &teams[i];
            break;
        }
    }

    for (int i = 0; i < size; ++i)
    {
        if (strcmp(teams[i].get_name(), group2) == 0)
        {
            team2 = &teams[i];
            break;
        }
    }

    if (team1 == nullptr || team2 == nullptr)
    {
        return false;
    }
    team1->game(points1, points2);
    team2->game(points2, points1);

    return true;
}
void League::print() const
{
    cout << "League standings and statistics:" << endl;
    for (int i = 0; i < size; ++i)
        teams[i].print();
}
